#!/bin/bash

# Get the current UTC time and subtract one hour
# start_time=$(date -u -d '1 hour ago' +"%Y-%m-%dT%H:%M:%S.000Z")
start_time=$(date -u -d '1 day ago' +"%Y-%m-%dT%H:%M:%S.000Z")
end_time=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")

# NVD API URL
NVD_API_URL="https://services.nvd.nist.gov/rest/json/cves/2.0"

# Make the API request
response=$(curl -s "${NVD_API_URL}?pubStartDate=${start_time}&pubEndDate=${end_time}&startIndex=0&resultsPerPage=1")

# Extract total results using jq (ensure jq is installed)
if command -v jq >/dev/null 2>&1; then
    total_results=$(echo "$response" | jq -r '.totalResults')
    echo "Number of CVEs published in the last day: $total_results"
else
    echo "Error: jq is not installed. Install jq to parse JSON."
fi
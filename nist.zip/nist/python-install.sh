#!/bin/bash

# Ensure script runs as root
if [ "$(id -u)" -ne 0 ]; then
    echo "Please run as root or use sudo."
    exit 1
fi

# Update package list
echo "Updating package list..."
apt update -y

# Install dependencies
echo "Installing dependencies..."
apt install -y software-properties-common

# Install Python
echo "Installing Python..."
apt install -y python3 python3-pip python3-venv pyenv

# Verify installation
echo "Checking Python installation..."
python3 --version && pip3 --version

# Set python3 as default "python"
if ! command -v python &> /dev/null; then
    echo "Creating a symlink for python3 as default python..."
    ln -s /usr/bin/python3 /usr/bin/python
fi

echo "Python installation completed successfully!"

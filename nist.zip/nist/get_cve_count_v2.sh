#!/bin/bash

# Get the current UTC time and subtract one day
start_time=$(date -u -d '1 day ago' +"%Y-%m-%dT%H:%M:%S.000Z")
end_time=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")

# NVD API URL
NVD_API_URL="https://services.nvd.nist.gov/rest/json/cves/2.0"

# Perform API request and store response headers separately
response=$(curl -s -w "%{http_code}" -o response.json "${NVD_API_URL}?pubStartDate=${start_time}&pubEndDate=${end_time}&startIndex=0&resultsPerPage=100")

# Extract HTTP status code
http_status="${response: -3}"

echo "HTTP Status Code: $http_status"

# Check if HTTP status is 200 (OK)
if [[ "$http_status" != "200" ]]; then
    echo "Error: Failed to retrieve data from NIST API."
    exit 1
fi

# Check if jq is installed
if ! command -v jq >/dev/null 2>&1; then
    echo "Error: jq is not installed. Install jq to parse JSON."
    exit 1
fi

# Extract total CVE count
total_results=$(jq -r '.totalResults' response.json)
echo "Number of CVEs published in the last 24 hours: $total_results"

# Extract and format CVE details
echo -e "\nList of CVEs:"
jq -r '.vulnerabilities[] | .cve | 
    "CVE ID: " + .id + 
    "\nCWE: " + (.weaknesses[0].description[0].value // "N/A") +
    "\nName: " + (.descriptions[] | select(.lang == "en") | .value) +
    "\nSeverity: " + (.metrics.cvssMetricV31[0].cvssData.baseSeverity // "N/A") +
    "\nStatus: " + (.vulnStatus // "N/A") + "\n--------------------------"' response.json

sudo apt remove --purge -y python3 python3-dev python3-venv python3-pip
sudo apt autoremove -y

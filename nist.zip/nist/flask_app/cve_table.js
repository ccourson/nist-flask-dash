const columns = [
  { field: "id", headerName: "CVE ID", width: 200 },
  {
    field: "description",
    headerName: "Description",
    width: 500,  // Adjust column width
    renderCell: (params) => (
      <div style={{ whiteSpace: "normal", wordBreak: "break-word", maxWidth: "500px" }}>
        {params.value}
      </div>
    ),
  },
  { field: "published", headerName: "Published Date", width: 200 },
];

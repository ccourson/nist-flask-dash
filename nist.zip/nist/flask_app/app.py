from flask import Flask, jsonify
import requests
import datetime
import json


app = Flask(__name__)

NIST_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"

def fetch_cve_data():
    """Fetch CVE data from NIST for the last 24 hours."""
    yesterday = (datetime.datetime.utcnow() - datetime.timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S')
    params = {
        "pubStartDate": f"{yesterday}Z",
        "pubEndDate": f"{datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')}Z"
    }
    response = requests.get(NIST_API_URL, params=params)
    print(f"Status: {response.status_code}")
    if response.status_code == 200:
        with open("response.json", "w") as f:
            f.write(json.dumps(response.json(), indent=4, sort_keys=True))
    return response.json().get("vulnerabilities", {}) if response.status_code == 200 else []

@app.route('/cve-data', methods=['GET'])
def get_cve_data():
    """API Endpoint to return CVEs from the last day."""
    data = fetch_cve_data()
    processed_data = [
        {
            "id": vuln["cve"]["id"],
            "description": vuln["cve"]["descriptions"][0]["value"],
            "published": vuln["cve"]["published"]
        }
        for vuln in data
    ]
    return jsonify(processed_data)

if __name__ == '__main__':
    app.run(debug=True, port=5000)

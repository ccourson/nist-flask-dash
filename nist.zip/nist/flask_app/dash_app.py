from dash import Dash, dcc, html, dash_table
import requests
import dash_bootstrap_components as dbc

app = Dash(__name__, external_stylesheets=[dbc.themes.CYBORG])  # Try BOOTSTRAP or LUX for other styles

# Fetch CVE data from Flask API
def fetch_cve_data():
    response = requests.get("http://localhost:5000/cve-data")
    return response.json() if response.status_code == 200 else []

# Get the data
table_data = fetch_cve_data()

app.layout = dbc.Container([
    html.H1("Recent CVE Reports", className="text-center mt-4"),

    dash_table.DataTable(
        columns=[
            {"name": "CVE ID", "id": "id"},
            {"name": "Description", "id": "description"},
            {"name": "Published Date", "id": "published"},
        ],
        data=table_data,
        page_size=10,
        style_table={"overflowX": "auto"},
        style_cell={"padding": "10px", "textAlign": "left"},
        style_data_conditional=[
            {
                "if": {"column_id": "description"},
                "whiteSpace": "normal",
                "wordBreak": "break-word",
                "maxWidth": "500px",  # Adjust width as needed
            }
        ]
    )
], fluid=True)

if __name__ == "__main__":
    app.run_server(debug=True, port=8050)

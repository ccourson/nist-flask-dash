# gunicorn_config.py
import multiprocessing

bind = "0.0.0.0:5000"  # Flask app will run on port 5000
workers = multiprocessing.cpu_count() * 2 + 1  # Number of workers
threads = 2  # Number of threads per worker
timeout = 120  # Request timeout in seconds
loglevel = "info"
accesslog = "-"  # Log to stdout
errorlog = "-"   # Log to stderr

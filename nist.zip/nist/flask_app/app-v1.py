from flask import Flask, jsonify
import requests
import sqlite3
import datetime

app = Flask(__name__)

# NIST CVE API Endpoint
NIST_API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"

def fetch_cve_data():
    """Fetch CVE data from NIST for the last 24 hours."""
    yesterday = (datetime.datetime.utcnow() - datetime.timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S')
    params = {
        "pubStartDate": f"{yesterday}Z",
        "pubEndDate": f"{datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')}Z"
    }
    response = requests.get(NIST_API_URL, params=params)
    return response.json() if response.status_code == 200 else {"error": "Failed to fetch data"}

@app.route('/cve-data', methods=['GET'])
def get_cve_data():
    """API Endpoint to return CVEs from the last day."""
    data = fetch_cve_data()
    return jsonify(data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
